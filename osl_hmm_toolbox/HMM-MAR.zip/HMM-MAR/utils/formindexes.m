function Sind = formindexes(orders,S)
p = length(orders); 
Sind = repmat(S,p,1);
end
